import { CurrentLoanDetails } from './current-loan-details';

describe('CurrentLoanDetails', () => {
  it('should create an instance', () => {
    expect(new CurrentLoanDetails()).toBeTruthy();
  });
});

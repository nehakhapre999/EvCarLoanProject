export class CustomerVerification {
    verificationID:number;
    verificationDate:string;
    status:string;
    remark:string;



}

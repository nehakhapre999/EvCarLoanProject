import { Cibil } from './cibil';

export class Enquirydetails {
    eId:number;
    firstName:String;
    lastName:String;
    age:number;
    email:string;
    mobileno:number;
    pancardNo:string;
    cibil:Cibil;
}

export class Document {

documentId:number
customerId:number
customerName : string
adharcard:any[];
pancard:any[];
signature:any[];
photo : any[];
incomeProof:any[];
}

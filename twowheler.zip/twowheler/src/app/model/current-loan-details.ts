import { EmiCalculator } from "./emi-calculator";
import { EmiDetail } from "./emi-detail";
import { PreviousLoanDetails } from "./previous-loan-details";

export class CurrentLoanDetails {
    loanId:number;
    loanAmount: number;
    loanRoi:number;
    loanTenure:number;
    loanAmounttobePaid:number;
    sanctionAmount:number;
    bankname:string;
    emicalculator:EmiCalculator;
    previousloandetails:PreviousLoanDetails;

}

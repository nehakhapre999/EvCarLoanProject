export class GuarantorDetail {
    guarantorId:number;
    guarantorname:string;
    guarantorDOB:string;
    guarantornumber:string;
    guarantorjob:string;
    guarantoraddress:string;
    
}

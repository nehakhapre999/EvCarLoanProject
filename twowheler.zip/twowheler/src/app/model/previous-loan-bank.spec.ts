import { PreviousLoanBank } from './previous-loan-bank';

describe('PreviousLoanBank', () => {
  it('should create an instance', () => {
    expect(new PreviousLoanBank()).toBeTruthy();
  });
});

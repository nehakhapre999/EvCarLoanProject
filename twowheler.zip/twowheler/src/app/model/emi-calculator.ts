export class EmiCalculator {

    emiId:number;
	cid:number;
	emiAmount:number;
	EmiDate:string;
	EmiStatus:string;	
	emino:number;
	balanceAmount:number;
}

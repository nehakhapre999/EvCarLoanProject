import { AccountDetails } from "./account-details";
import { Cibil } from "./cibil";
import { CurrentLoanDetails } from "./current-loan-details";
import { CustomerVerification } from "./customer-verification";
import { GuarantorDetail } from "./guarantor-detail";
import { Profession } from "./profession";
import { SanctionLetter } from "./sanction-letter";

export class Customer {
  cId: number;
  cname:string;
  email:string
  // cibil:Cibil;
  currentloandetails:CurrentLoanDetails;
  //customerverification:CustomerVerification;
   //profession:Profession;
  accountdetails:AccountDetails;
  //guarantorDetail:GuarantorDetail;
  sanctionletter:SanctionLetter;
  status:string;
  sanctionId: any;
  
  }



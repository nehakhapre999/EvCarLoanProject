import { EmiCalculator } from './emi-calculator';

describe('EmiCalculator', () => {
  it('should create an instance', () => {
    expect(new EmiCalculator()).toBeTruthy();
  });
});

import { SanctionLetter } from './sanction-letter';

describe('SanctionLetter', () => {
  it('should create an instance', () => {
    expect(new SanctionLetter()).toBeTruthy();
  });
});

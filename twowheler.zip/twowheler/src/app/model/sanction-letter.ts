export class SanctionLetter {
    cId:number;
    sanctionId:number;
    tenure:number;
    rateofInt:number;
    customerTotalLoanRequired:number;
    bankName:String;
    accountNumber:number;
    sanctionAmount:number;
}

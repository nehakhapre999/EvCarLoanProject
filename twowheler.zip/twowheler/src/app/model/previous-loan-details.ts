import { PreviousLoanBank } from "./previous-loan-bank";

export class PreviousLoanDetails {
    preloanId:number;
    preloanAmount:number;
    preloanTenure:number;
    preloanEmi:number;
    preloanPaidAmount:number;
    preloanRemainingAmount:number;
    preLoanType:string;
    preLoanStauts:string;


}

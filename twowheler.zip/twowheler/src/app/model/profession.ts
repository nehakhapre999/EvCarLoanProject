export class Profession {
    profeesionID:number;
    professionType:string;
    professionSalary:number;
    professionDesignation:string;

}

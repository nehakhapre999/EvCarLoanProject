export class AccountDetails {
    accountid:number;
    accounttype:string;
    accountbalance:number;
    accountholdername:string;
    accountstatus:string;
    accountnumber:number;

}

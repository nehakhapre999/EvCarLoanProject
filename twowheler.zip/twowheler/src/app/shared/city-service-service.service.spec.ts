import { TestBed } from '@angular/core/testing';

import { CityServiceServiceService } from './city-service-service.service';

describe('CityServiceServiceService', () => {
  let service: CityServiceServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CityServiceServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

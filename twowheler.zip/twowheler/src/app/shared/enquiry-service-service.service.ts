//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import { Customer } from 'app/model/Customer';
import { Enquirydetails } from 'app/model/enquirydetails';
import { Observable, pipe } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { SanctionLetter } from 'app/model/sanction-letter';


@Injectable({
  providedIn: 'root'
})
export class EnquiryServiceServiceService {

  eId:number;
  firstName:String;
  lastName:String;
  age:number;
  email:string;
  mobileno:number;
  pancardNo:string;
  cibilscore:number
  sanctionId: number;

  
  constructor(private http: HttpClient) { }

  ed:Enquirydetails={
    eId:0,
    firstName:'',
    lastName:'',
    age:0,
    email:'',
    mobileno:0,
    pancardNo:'',
    cibil:null
  }

  sb:SanctionLetter= {
    cId:0,
    sanctionId: 0,
    tenure: 0,
    rateofInt: 0,
    customerTotalLoanRequired: 0,
    bankName: '',
    accountNumber: 0,
    sanctionAmount: 0,
  }
  
  custobj:Customer={
    cId: 0,
    cname: '',
    status: 'pending',
    email: '',
    accountdetails: {
      accountid: 0,
      accounttype: '',
      accountbalance: 0,
      accountholdername: '',
      accountstatus: '',
      accountnumber: 0
    },

    currentloandetails: {
      loanId: 0,
      loanAmount: 0,
      loanRoi: 0,
      loanTenure: 0,
      loanAmounttobePaid: 0,
      sanctionAmount: 0,
      bankname: "",
      emicalculator: {

        emiId:0,
        cid:0,
        emiAmount:0,
        EmiDate:'',
        EmiStatus:'',	
        emino:0,
        balanceAmount:0
      },
      previousloandetails: {
        preloanId: 0,
        preloanAmount: 0,
        preloanTenure: 0,
        preloanEmi: 0,
        preloanPaidAmount: 0,
        preloanRemainingAmount: 0,
        preLoanType: '',
        preLoanStauts: '',
      }
    },

    sanctionletter: {
      cId:0,
      sanctionId: 0,
      tenure: 0,
      rateofInt: 0,
      customerTotalLoanRequired: 0,
      bankName: '',
      accountNumber: 0,
      sanctionAmount: 0,
    },
    sanctionId: 0
  }
   
  

  // sanctionedcustobj:Customer={
  //   cId: 0,
  //   cname: '',
  //   status: 'Verified',
  //   email: '',
  //   accountdetails: {
  //     accountid: 0,
  //     accounttype: '',
  //     accountbalance: 0,
  //     accountholdername: '',
  //     accountstatus: '',
  //     accountnumber: 0
  //   },

  //   currentloandetails: {
  //     loanId: 0,
  //     loanAmount: 0,
  //     loanRoi: 0,
  //     loanTenure: 0,
  //     loanAmounttobePaid: 0,
  //     sanctionAmount: 0,
  //     bankname: '',
  //     emidetails: {
  //       emiId: 0,
  //       emiAmountMonthly: 0,
  //       nextEmiDueDate: '',
  //       previousEmiStatus: '',
  //     },
  //     previousloandetails: {
  //       preloanId: 0,
  //       preloanAmount: 0,
  //       preloanTenure: 0,
  //       preloanEmi: 0,
  //       preloanPaidAmount: 0,
  //       preloanRemainingAmount: 0,
  //       preLoanType: '',
  //       preLoanStauts: '',
  //     }
  //   },
  //   sanctionletter: {
  //     cId:0,
  //     sanctionId: 0,
  //     tenure: 0,
  //     rateofInt: 0,
  //     customerTotalLoanRequired: 0,
  //     bankName: '',
  //     accountNumber: 0,
  //     sanctionAmount: 0,
  //   },
  //   sanctionId: 0
  // }
     
    


  url:string="http://localhost:9091"
  save()
  {
   return this.http.post<Enquirydetails>(this.url+"/saveenq1",this.ed)
  }
  getCibil(eId)
  {
   // console.log("eid" + this.ed.eId);
   return this.http.get<String>(this.url+"/getcibil/"+eId);
  }
  savecust()
  {

    return this.http.post<Customer>(this.url+"/savecustomerdata",this.custobj);
  
  }

  savesanctionedcust(s:SanctionLetter,id:number):Observable<SanctionLetter>
  {
    alert(id)
    return this.http.put<SanctionLetter>(this.url+"/ledger/"+id,s);
  }
    
  
  update()
  {
    return null  // this.http.put<Enquirydetails>(this.url+"/update",this.ed)
  }
  delete(id:number)
  {
    return null // this.http.delete<Enquirydetails>(this.url+"/delete/"+id)
  }
  getAll():any
  {
    return this.http.get<Enquirydetails>(this.url+"/getenqlist")
  }

  getAllCust():any
  {
    return this.http.get<Customer>(this.url+"/getcustomerData")
  }

  upload(em:FormData){
    return this.http.post(this.url+"/saveDoc", em);
  }

  postDocument(uploadDocument: any) : Observable<Document> {
    
    //alert("welcome to angular")        
    // const headers={'content-type': 'application/json'}
   

    return this.http.post<Document>("http://localhost:9091/docupload", uploadDocument);
  }

   getData(cId:number):Observable<any>{
    return this.http.get<Document[]>("http://localhost:9091/getDocs/"+cId);
  }

  getVerifiedCust():any
  {
    return this.http.get<Customer>(this.url +"/getVerifiedCustomer");
  }

  getSanction(id:number){
    return this .http.get<SanctionLetter>(this.url+"/getSingleData/"+id);
  }

  //Disbursement
  getApplicantsWithStatus(status:string): any {
    return this.http.get(this.url+"/getbystatus/"+status);
  }

  loanDisbs(id:number){
    return this.http.put<SanctionLetter>(this.url+"/ledger/"+id,this.sb);
  }

  genPdf(loanno:number):any{
    return this.http.get(this.url+"/pdfgenerate/"+loanno,{observe:'response',responseType:'blob'});
  }

  genExcel(loanno:number):any{
    alert("service")
    return this.http.get(this.url+"/excelfile/"+loanno,{observe:'response',responseType:'blob'});

  }

}
 

   





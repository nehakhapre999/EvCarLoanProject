import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'app/model/Customer';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';

@Component({
  selector: 'app-sanction',
  templateUrl: './sanction.component.html',
  styleUrls: ['./sanction.component.css']
})
export class SanctionComponent implements OnInit {
  
  sanctionForm:FormGroup;
   data:Customer;
  constructor(public es:EnquiryServiceServiceService,public router:Router,public fb:FormBuilder) { }

  ngOnInit(): void {

    this.sanctionForm=this.fb.group({

      cId:[this.es.sb.cId,[Validators.required]],
      sanctionId:[this.es.sb.sanctionId,[Validators.required]],
      bankName:[this.es.sb.bankName],
      accountNumber:[this.es.sb.accountNumber],
      tenure:[this.es.sb.tenure],
      sanctionAmount:[this.es.sb.sanctionAmount],
      rateofInt:[this.es.sb.rateofInt],
      customerTotalLoanRequired:[this.es.sb.customerTotalLoanRequired],


    })}
    

     save(){

      
    this.es.savesanctionedcust(this.sanctionForm.value,this.sanctionForm.get('cId').value).subscribe();

    alert("data saved");
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'app/model/Customer';
import { SanctionLetter } from 'app/model/sanction-letter';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';

@Component({
  selector: 'app-accounthead',
  templateUrl: './accounthead.component.html',
  styleUrls: ['./accounthead.component.css']
})
export class AccountheadComponent implements OnInit {
  AccountheadComponent: any;

  constructor(public es:EnquiryServiceServiceService,public router:Router) { }
 custlist:Customer[];
  ngOnInit(): void {

    this.es.getVerifiedCust().subscribe((data:Customer[])=>
    {
      
      this.custlist=data;
      // console.log("Cust id :"+this.custlist[0].status);
    })
  }

  sanction(id:number){
    
     //this.es.sanctionId=id;
     //this.es.custobj.cId = id;

     this.es.getSanction(id).subscribe((d:SanctionLetter)=>
     {
      console.log(d);

      this.es.sb=d;
      
  
    console.log(this.es.sb);  
  
  
  setTimeout(() => {this.routing()},2000*1);
  
     
  })

  }

  routing(){
  
    this.router.navigateByUrl("role/ac/sanction");
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountheadComponent } from './accounthead/accounthead/accounthead.component';
import { RouterModule, Routes } from '@angular/router';
import { SanctionComponent } from './accounthead/sanction/sanction.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


const routing: Routes = [
  {path: "account", component:AccountheadComponent },
  {path:'sanction',component:SanctionComponent},
  
];
@NgModule({
  declarations: [AccountheadComponent, SanctionComponent],
  imports: [
    CommonModule,RouterModule.forChild(routing),ReactiveFormsModule,FormsModule
  ]
})
export class AccountheadModule { }

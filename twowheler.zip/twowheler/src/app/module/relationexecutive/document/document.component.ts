import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {

  constructor(public fb:FormBuilder,public es:EnquiryServiceServiceService,private router: Router) { }
  docForm!:FormGroup;

  //retrived doc : is to get docs
   retrievedDoc:any;
 //all selected photos stored in below fields
   selectedadharcard:any;
   selectedpancard:any;
   selectedsignature:any;
   selectedphotos:any;
   selectedincomeproof:any;
 
   
 
  
   reader=new FileReader();
 
 
  
   
   ngOnInit(): void {
 
     this.docForm=this.fb.group({
 
       customerId:[this.es.custobj.cId,[Validators.required]],
       customerName:[this.es.custobj.cname]
     })
    
   }
 
   onselectedFile1(event:any)
   {
     alert("hello")
     this.selectedadharcard=event.target.files[0];
   alert(this.selectedadharcard);
    const file = event.target.files[0];
 //  this.reader.onload = e => this.imageSrc1 = this.reader.result;
     this.reader.readAsDataURL(file);
   }
   onselectedFile2(event:any){
     this.selectedpancard=event.target.files[0];
     const file = event.target.files[0];
     // this.reader.onload = e => this.imageSrc2 = this.reader.result;
        this.reader.readAsDataURL(file);
      
    
   }
   onselectedFile3(event:any){this.selectedsignature=event.target.files[0];}
  
   onselectedFile4(event:any){this.selectedphotos=event.target.files[0];}
   onselectedFile5(event:any){this.selectedincomeproof=event.target.files[0];}
  
   save()
 
   {
     alert("Document Uploaded")
     const document1=JSON.stringify(this.docForm.value);
   // create object formdata
     const uploadDocument= new FormData();
   // store file formdata
     uploadDocument.append("adharcard",this.selectedadharcard);
     uploadDocument.append("pancard",this.selectedpancard);
     uploadDocument.append("signature",this.selectedsignature);
     uploadDocument.append("photo",this.selectedphotos);
     uploadDocument.append("incomeProof",this.selectedincomeproof);
     
     uploadDocument.append("customerId",document1);
 
     this.es.postDocument(uploadDocument).subscribe();
     console.log("Upload Method")
   
   
     // window.location.reload();
 
   }
   
}

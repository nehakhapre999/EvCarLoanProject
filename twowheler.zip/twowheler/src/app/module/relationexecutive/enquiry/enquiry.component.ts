import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Enquirydetails } from 'app/model/enquirydetails';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {

  enquirydetailslist:Enquirydetails[]

  constructor(public es:EnquiryServiceServiceService,private router: Router) { }
  ngOnInit(): void {
    
      }
  save()
{
 // if(this.es.eID==0)
 // {
    this.es.save().subscribe();
    alert("Data Saved");
    this.router.navigateByUrl("role/relation/oeenq");
 // }
 // else{
   // this.es.update().subscribe()
  //}
 
}
}

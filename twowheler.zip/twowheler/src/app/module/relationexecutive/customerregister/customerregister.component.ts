import { formatNumber } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'app/model/Customer';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {
 

  

  constructor(public es:EnquiryServiceServiceService,public router:Router ) { }
  step:number;
  
  ngOnInit(): void {
    this.step = 1;
  }

  next() {
    this.step = this.step + 1;
    alert(this.step);
  }
  
  previous() {
    this.step = this.step - 1;
  }
     
  save()
   {
        alert("data saved");
        this.es.savecust().subscribe();
    
      
      
        this.router.navigateByUrl("role/relation/oedocument");
    
  
    
   
  }
  
  
  }
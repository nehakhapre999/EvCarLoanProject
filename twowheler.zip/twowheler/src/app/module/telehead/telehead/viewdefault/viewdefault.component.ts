import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdefault',
  templateUrl: './viewdefault.component.html',
  styleUrls: ['./viewdefault.component.css']
})
export class ViewdefaultComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

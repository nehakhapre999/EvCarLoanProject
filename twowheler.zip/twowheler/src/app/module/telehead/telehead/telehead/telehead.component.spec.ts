import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeleheadComponent } from './telehead.component';

describe('TeleheadComponent', () => {
  let component: TeleheadComponent;
  let fixture: ComponentFixture<TeleheadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeleheadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeleheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

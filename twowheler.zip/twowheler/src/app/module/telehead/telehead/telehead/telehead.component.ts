import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-telehead',
  templateUrl: './telehead.component.html',
  styleUrls: ['./telehead.component.css']
})
export class TeleheadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

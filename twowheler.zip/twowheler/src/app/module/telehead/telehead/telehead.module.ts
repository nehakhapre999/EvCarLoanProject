import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TeleheadComponent } from './telehead/telehead.component';
import { ViewdefaultComponent } from './viewdefault/viewdefault.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

const routing: Routes = [
  {path: 'telehead', component:TeleheadComponent },
  {path:'default',component:ViewdefaultComponent},

  
];

@NgModule({
  declarations: [TeleheadComponent, ViewdefaultComponent],
  imports: [
    CommonModule,FormsModule,RouterModule.forChild(routing),ReactiveFormsModule
  ]
  
})
export class TeleheadModule { }

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayerlistComponent } from './payerlist.component';

describe('PayerlistComponent', () => {
  let component: PayerlistComponent;
  let fixture: ComponentFixture<PayerlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayerlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payerlist',
  templateUrl: './payerlist.component.html',
  styleUrls: ['./payerlist.component.css']
})
export class PayerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

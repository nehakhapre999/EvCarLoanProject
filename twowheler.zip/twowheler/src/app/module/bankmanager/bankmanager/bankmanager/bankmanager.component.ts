import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'app/model/Customer';
import { SanctionLetter } from 'app/model/sanction-letter';
import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-bankmanager',
  templateUrl: './bankmanager.component.html',
  styleUrls: ['./bankmanager.component.css']
})
export class BankmanagerComponent implements OnInit {
  custlist:Customer[];
  
  constructor(public es:EnquiryServiceServiceService,public router:Router) { }

  ngOnInit(): void {
    this.es.getApplicantsWithStatus("sanction").subscribe((data:Customer[])=>
    {
      
      this.custlist=data;
      
    })

    
  }
  sanction(id:number)
  {   
    this.es.custobj.cId=id;
    this.es.getSanction(id).subscribe((data:SanctionLetter)=>
    {
      this.es.custobj.sanctionId=data
    
    console.log(this.es.sb);

    
  })

}


disburstment() {
  Swal.fire('HELLO!!!', 'We have been informed your loan is disbursed!', 'success');
}

pdf(id:number)
{ 
window.open("http://localhost:9091/pdfgenerate/"+id)
} 

excel(id:number)
{ 
window.open("http://localhost:9091/excelfile/"+id)
} 

}

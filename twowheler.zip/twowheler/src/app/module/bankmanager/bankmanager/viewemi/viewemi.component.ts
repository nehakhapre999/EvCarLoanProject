import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewemi',
  templateUrl: './viewemi.component.html',
  styleUrls: ['./viewemi.component.css']
})
export class ViewemiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

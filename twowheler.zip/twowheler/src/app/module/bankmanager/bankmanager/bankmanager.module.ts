import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankmanagerComponent } from './bankmanager/bankmanager.component';
import { RouterModule, Routes } from '@angular/router';
import { ViewemiComponent } from './viewemi/viewemi.component';
import { PayerlistComponent } from './payerlist/payerlist.component';

const routing: Routes = [
  {path: "bank", component:BankmanagerComponent },
  {path:'payerlist',component:PayerlistComponent},
  {path:'viewemi',component:ViewemiComponent}
  
];

@NgModule({
  declarations: [BankmanagerComponent, ViewemiComponent, PayerlistComponent],
  imports: [
    
      CommonModule,RouterModule.forChild(routing)
  ]
})
export class BankmanagerModule { }

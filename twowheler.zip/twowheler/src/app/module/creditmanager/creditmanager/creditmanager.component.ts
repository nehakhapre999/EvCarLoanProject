import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'app/model/Customer';

import { EnquiryServiceServiceService } from 'app/shared/enquiry-service-service.service';

@Component({
  selector: 'app-creditmanager',
  templateUrl: './creditmanager.component.html',
  styleUrls: ['./creditmanager.component.css']
})
export class CreditmanagerComponent implements OnInit {

  retrievedDoc:any;
  docFlag:any;
  custlist:Customer[];
  step:number;
  id:number;
  
  constructor(public es:EnquiryServiceServiceService,private router: Router) { }

  ngOnInit(): void {
    this.step = 1;
    this.es.getAllCust().subscribe((data:Customer[])=>
    {
      
      this.custlist=data;
      // console.log("Cust id :"+this.custlist[0].status);
    })
   }

   image(a:Customer)
{
  this.docFlag = "show";
  this.es.getData(a.cId).subscribe((d:Document[])=>{

    this.retrievedDoc = d;

  });
}

approved(a:Customer)
{
  a.status = "Approved";
  
  this.es.custobj = a;
  this.es.savecust().subscribe(); 
  //this.ngOnInit();
}

rejected(a:Customer)
{
  a.status = "Rejected";
 
  this.es.custobj = a;
  this.es.savecust().subscribe();
  //this.ngOnInit();
}
// verified(id:number){
//   alert("Success");
//   this.retrievedDoc.cId = id;
//   this.es.custobj.status="Verified";
  
//   this.es.savecust().subscribe();

// }
// failed(a:Customer){
//   alert("Failed");
//   a.status="Failed";
//    this.es.custobj = a;
//   this.es.savecust().subscribe();
 
// }

next() {
  this.step = this.step + 1;
}

previous() {
  this.step = this.step - 1;
}

}


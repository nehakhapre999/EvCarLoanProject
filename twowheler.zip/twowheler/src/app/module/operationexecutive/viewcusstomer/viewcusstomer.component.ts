import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcusstomer',
  templateUrl: './viewcusstomer.component.html',
  styleUrls: ['./viewcusstomer.component.css']
})
export class ViewcusstomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

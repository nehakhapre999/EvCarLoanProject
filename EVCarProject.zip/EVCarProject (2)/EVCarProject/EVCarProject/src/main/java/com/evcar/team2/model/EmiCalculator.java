package com.evcar.team2.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class EmiCalculator {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int emiId;
	private int cid;
	private float emiAmount;
	private LocalDate EmiDate;
	private String EmiStatus;	
	private int emino;
	private float balanceAmount;
	public int getEmiId() {
		return emiId;
	}
	public void setEmiId(int emiId) {
		this.emiId = emiId;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public float getEmiAmount() {
		return emiAmount;
	}
	public void setEmiAmount(float emiAmount) {
		this.emiAmount = emiAmount;
	}
	public LocalDate getEmiDate() {
		return EmiDate;
	}
	public void setEmiDate(LocalDate emiDate) {
		EmiDate = emiDate;
	}
	public String getEmiStatus() {
		return EmiStatus;
	}
	public void setEmiStatus(String emiStatus) {
		EmiStatus = emiStatus;
	}
	public int getEmino() {
		return emino;
	}
	public void setEmino(int emino) {
		this.emino = emino;
	}
	public float getBalanceAmount() {
		return balanceAmount;
	}
	public void setBalanceAmount(float balanceAmount) {
		this.balanceAmount = balanceAmount;
	}
	
	

	
	

}

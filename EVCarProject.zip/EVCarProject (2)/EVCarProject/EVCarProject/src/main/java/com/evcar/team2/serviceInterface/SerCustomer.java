package com.evcar.team2.serviceInterface;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;


import com.evcar.team2.model.Customer;
import com.evcar.team2.model.SanctionLetter;

public interface SerCustomer {

//public	Customer saveData(Customer cust);

public Customer getdatabyId(int custid);

public void editcustomer(Customer cust);

public void delcust(int cId);

// Customer saveuploadDoc(Customer all);

public List<Customer> getByStatus(String status);

//public void saveallcust(Customer cust);

public void saveData(Customer cust);

public Iterable<Customer> getcustomerData();

public Iterable<Customer> getVerifiedCustomer();

public SanctionLetter getSinglesanction(int cId);

public void upsanctionletter(SanctionLetter sl);









}

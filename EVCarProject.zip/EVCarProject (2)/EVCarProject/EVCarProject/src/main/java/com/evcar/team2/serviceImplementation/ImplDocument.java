package com.evcar.team2.serviceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.evcar.team2.model.Document;
import com.evcar.team2.repository.RepoAllpersonalDoc;
import com.evcar.team2.serviceInterface.ServiceAllPersonalDoc;

@Service

public class ImplDocument implements ServiceAllPersonalDoc
{
@Autowired
RepoAllpersonalDoc dpi;

@Override
public Document savedoc(Document alldoc) {
	
	dpi.save(alldoc);
	return alldoc;
}

@Override
public Iterable<Document> getDoc(int custid) {
	
	return dpi.findAll();
}


}

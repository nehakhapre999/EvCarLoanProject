package com.evcar.team2.serviceImplementation;

import org.springframework.stereotype.Service;

import com.evcar.team2.serviceInterface.SerEmiCalcilator;


public class ImplEmiDetail implements SerEmiCalcilator{

}

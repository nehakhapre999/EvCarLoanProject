package com.evcar.team2.serviceInterface;

public interface SerSanctionLetter {

}

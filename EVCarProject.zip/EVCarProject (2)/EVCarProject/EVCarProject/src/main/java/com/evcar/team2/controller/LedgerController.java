package com.evcar.team2.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.evcar.team2.model.Customer;
import com.evcar.team2.model.SanctionLetter;
import com.evcar.team2.serviceInterface.SerCustomer;
import com.evcar.team2.serviceInterface.SerLedger;

@CrossOrigin
@RestController
public class LedgerController {
	
	
    @Autowired
	SerLedger sl;
    
    @Autowired
	SerCustomer sc;

    
    
    
	
		
	@GetMapping("/excelfile/{id}")
	public void createExcel(HttpServletResponse response,@PathVariable int id)
	{
		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment;filename=data.xls");
		sl.generateExel(response,id);
		
	}
	
	
	
	@GetMapping("/pdfgenerate/{id}")
	public void createpdf(HttpServletResponse response1,@PathVariable int id)
	{
		response1.setContentType("application/pdf");
		
		String hk="Content-Disposition";
		String val="attachment;filename=DATA.pdf";

		response1.setHeader(hk, val);

		sl.generatePdf(response1,id);
	}
	
	@PutMapping("/ledger/{id}")
	public void createledger(@RequestBody SanctionLetter s,@PathVariable int id)
	{
		
		System.out.println(id);
		System.out.println(s.getcId());
		Customer ct = sc.getdatabyId(id);
		System.out.println(ct.getCname());
		ct.getSanctionletter().setSanctionAmount(s.getSanctionAmount());
		ct.getSanctionletter().setRateofInt(s.getRateofInt());
		ct.getSanctionletter().setcId(id);
		ct.setStatus("sanction");
		System.out.println(ct.getSanctionletter());
		sc.saveData(ct);
		
		Integer data = sl.saveData(s);
		
		
	
	}

	
	
	

}

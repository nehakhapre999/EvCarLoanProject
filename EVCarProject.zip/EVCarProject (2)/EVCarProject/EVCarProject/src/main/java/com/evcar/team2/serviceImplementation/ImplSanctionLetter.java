package com.evcar.team2.serviceImplementation;

import com.evcar.team2.serviceInterface.SerSanctionLetter;

public class ImplSanctionLetter implements SerSanctionLetter{

}

package com.evcar.team2.serviceImplementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


import com.evcar.team2.model.Customer;
import com.evcar.team2.model.SanctionLetter;
import com.evcar.team2.repository.RepoCustomer;
import com.evcar.team2.repository.RepoSanctionLetter;
import com.evcar.team2.serviceInterface.SerCustomer;

@Service
public class ImplCustomer implements SerCustomer{

	@Autowired
	RepoCustomer rc;

//	@Override
//	public void saveData(Customer cust) {
//		rc.save(cust);
//		
//	}

	@Override
	public Customer getdatabyId(int custid) {
		
		Optional<Customer> cust = rc.findById(custid);
		Customer customer = cust.get();
		return customer;
		
	}

	@Override
	public void editcustomer(Customer cust) {
		
		rc.save(cust);
	}

	@Override
	public void delcust(int cId) {
		rc.deleteById(cId);
	}

	
	public List<Customer> getByStatus(String status) {		
		return rc.findByStatus(status);
	}

	

	@Override
	public void saveData(Customer cust) {
		rc.save(cust);
		
	}

	@Override
	public Iterable<Customer> getcustomerData() {
		
		return rc.findAll();
	}

	@Override
	public Iterable<Customer> getVerifiedCustomer() {
		
		return rc.findAll();
	}
	
	@Autowired
	RepoSanctionLetter rs;

	@Override
	public SanctionLetter getSinglesanction(int cId) {
		
				 Optional<Customer> getsingle = rc.findById(cId);

				 SanctionLetter sanctionletter = getsingle.get().getSanctionletter();
				 
				 sanctionletter.setcId(cId);
				 
				 return sanctionletter;
				 
				 
	}
	
	@Autowired
	RepoSanctionLetter rp;

	@Override
	public void upsanctionletter(SanctionLetter sl) {
		
		rp.save(sl);
		
		
	}

	
	
	

  


	

}

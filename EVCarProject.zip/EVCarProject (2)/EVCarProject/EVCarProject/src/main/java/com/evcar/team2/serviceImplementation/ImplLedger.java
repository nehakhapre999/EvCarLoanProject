package com.evcar.team2.serviceImplementation;

import java.awt.Color;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evcar.team2.model.EmiCalculator;

import com.evcar.team2.model.SanctionLetter;
import com.evcar.team2.repository.RepoCustomer;
import com.evcar.team2.repository.RepoEmiCalculator;
import com.evcar.team2.serviceInterface.SerLedger;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Service
public class ImplLedger implements SerLedger{
	
	@Autowired
	RepoEmiCalculator red;
	
	@Autowired
	RepoCustomer repocust;
	

	@Override
	public void generateExel(HttpServletResponse response,int id) {
		//Iterable<EmiDetail> custemi=red.findAll();
		
		List<EmiCalculator> list = red.findByCid(id);

		
		HSSFWorkbook wbook =new HSSFWorkbook();//creating new sheets
		HSSFSheet sheet=wbook.createSheet();
		HSSFRow row=sheet.createRow(0);
		

		
		HSSFFont headfont=wbook.createFont();
		headfont.setColor(IndexedColors.WHITE.index);
		
		CellStyle headerCellStyle=sheet.getWorkbook().createCellStyle();
		headerCellStyle.setDataFormat(wbook.createDataFormat().getFormat("#.##"));
		
		
		headerCellStyle.setFillForegroundColor(IndexedColors.LIME.index);
		 headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		  headerCellStyle.setFont(headfont);
		 
		HSSFCell cell1=row.createCell(0);
		cell1.setCellValue("EMI_ID");
		cell1.setCellStyle(headerCellStyle);
		
		HSSFCell cell2=row.createCell(1);
		cell2.setCellValue("EMI_DueDate");
		cell2.setCellStyle(headerCellStyle);
		
		HSSFCell cell3=row.createCell(2);
		cell3.setCellValue("EMI_AmountMonthly");
		cell3.setCellStyle(headerCellStyle);
		
		HSSFCell cell4=row.createCell(3);
		cell4.setCellValue("EMI_Balance_Amount");
		cell4.setCellStyle(headerCellStyle);
		
		
		HSSFCell cell5=row.createCell(4);
		cell5.setCellValue("EMI_Status");
		cell5.setCellStyle(headerCellStyle);
		
//		header.createCell(0).setCellValue("EMI_ID");
//		header.createCell(1).setCellValue("EMI_AmountMonthly");//create row with names
//		header.createCell(2).setCellValue("EMI_DueDate");
//		header.createCell(3).setCellValue("EMI_Status");
		
		
		
		int i=1;//row number
		for(EmiCalculator ei:list)
		{
			HSSFRow data=sheet.createRow(i);
			data.createCell(0).setCellValue(String.valueOf(i));
			data.createCell(1).setCellValue(ei.getEmiDate().toString());
			data.createCell(2).setCellValue(ei.getEmiAmount());
			data.createCell(3).setCellValue(ei.getBalanceAmount());
			data.createCell(4).setCellValue(ei.getEmiStatus());

			i++;
		}
		ServletOutputStream stream;
		
		try {
			stream = response.getOutputStream();
			wbook.write(stream);
			wbook.close();
			stream.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}


	@Override
	public void generatePdf(HttpServletResponse response1,int id) {
		//Iterable<> emipdf=red.findAll();
		List<EmiCalculator> emipdf=red.findByCid(id);

		
		Document doc1=new Document(PageSize.A4);
		try {
			PdfWriter.getInstance(doc1, response1.getOutputStream());
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		doc1.open();
		
		PdfPCell cell=new PdfPCell();
		cell.setBackgroundColor(Color.white);
		cell.setPadding(5);
		
		Font headlinefont=FontFactory.getFont(FontFactory.TIMES_BOLD);
		headlinefont.setSize(12);
		headlinefont.setColor(Color.RED);
		
		
		Font listfont=FontFactory.getFont(FontFactory.TIMES_BOLD);
		listfont.setSize(8);
		listfont.setColor(Color.BLACK);
		
		PdfPTable table=new PdfPTable(5);
		cell.setPhrase(new Phrase("EMI_ID",headlinefont));
		table.addCell(cell);
		
		cell.setPhrase(new Phrase("EMI_DueDate",headlinefont));
		table.addCell(cell);
		
		cell.setPhrase(new Phrase("EMI_AmountMonthly",headlinefont));
		table.addCell(cell);
		
		cell.setPhrase(new Phrase("EMI_BalanceAmount",headlinefont));
		table.addCell(cell);
		
		cell.setPhrase(new Phrase("EMI_Status",headlinefont));
		table.addCell(cell);

		int i=1;
		for(EmiCalculator ee:emipdf)
		{
			table.addCell(String.valueOf(i));
			table.addCell(String.valueOf(ee.getEmiDate().toString()));
			table.addCell(String.valueOf(ee.getEmiAmount()));
			table.addCell(String.valueOf(ee.getBalanceAmount()));
			table.addCell(String.valueOf(ee.getEmiStatus()));

			i++;
		}
		try {
			doc1.add(table);
		} catch (DocumentException e) {
			
			e.printStackTrace();
		}
		doc1.close();
	}


	@Override
	public Integer saveData(SanctionLetter c) {
		
		float princi = (float) c.getSanctionAmount();
		float month = (float) c.getTenure();
		float interest = (float) (c.getRateofInt() / 12) / 100;
		float emi = (float) ((princi * interest) * Math.pow(1 + interest, month) / (Math.pow(1 + interest, month) - 1));

		
		for (int i = 1; i <= month; i++) {
			EmiCalculator e = new EmiCalculator();
			e.setBalanceAmount(princi);
			e.setCid(c.getcId());//common cust id for all emi
			LocalDate now = LocalDate.of(2022, 8, 26);
			e.setEmiDate(now.plusMonths(i));
			e.setEmino(i);

			if (princi > emi) {
				e.setEmiAmount(emi);
			} else {
				e.setEmiAmount(princi);
			}
			float updatedPrinci = princi - (emi-interest*princi);

			e.setEmiStatus("Pending");

			princi = updatedPrinci;				
			 red.save(e);
		}
		return c.getcId();

		
	}



}

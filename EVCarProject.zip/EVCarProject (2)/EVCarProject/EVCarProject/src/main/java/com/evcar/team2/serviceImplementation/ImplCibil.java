package com.evcar.team2.serviceImplementation;

import org.springframework.stereotype.Service;

import com.evcar.team2.serviceInterface.SerCibil;


public class ImplCibil implements SerCibil{
	

}

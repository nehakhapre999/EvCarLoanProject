package com.evcar.team2.serviceImplementation;

import org.springframework.stereotype.Service;

import com.evcar.team2.serviceInterface.SerLoanDisbursement;


public class ImplLoanDisbursement implements SerLoanDisbursement{

}

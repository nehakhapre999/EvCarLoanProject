package com.evcar.team2.serviceInterface;

import javax.servlet.http.HttpServletResponse;

import com.evcar.team2.model.SanctionLetter;

public interface SerLedger {

	public void generateExel(HttpServletResponse response,int id);

	public void generatePdf(HttpServletResponse response1,int id);
	public Integer saveData(SanctionLetter c);

}

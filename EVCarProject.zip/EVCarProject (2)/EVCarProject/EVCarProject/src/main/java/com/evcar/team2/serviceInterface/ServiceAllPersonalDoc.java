package com.evcar.team2.serviceInterface;

import java.util.List;
import java.util.Optional;


import com.evcar.team2.model.Document;

public interface ServiceAllPersonalDoc {

	public Document savedoc(Document alldoc);

	public Iterable<Document> getDoc(int custid);

	

}

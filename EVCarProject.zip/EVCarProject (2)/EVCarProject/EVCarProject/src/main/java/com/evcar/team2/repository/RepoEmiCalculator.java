package com.evcar.team2.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.evcar.team2.model.EmiCalculator;


@Repository
public interface RepoEmiCalculator extends CrudRepository<EmiCalculator, Integer>{

	public List<EmiCalculator> findByCid(int id);

	//public void save(EmiCalculator e);

}
